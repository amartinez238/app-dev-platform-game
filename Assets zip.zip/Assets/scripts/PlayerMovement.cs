using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using System.Text;
using UnityEngine.Networking;


public class PlayerMovement : MonoBehaviour
{
    private Rigidbody2D rb; 
    private SpriteRenderer sprite;
    private Animator anim;
    private float movement;
    private float moveSpeed;
    private float jumpHeight;
    private PlayerData _playerData; // retrieved from playerData.cs

//IEnumerator Download(string id, System.Action<PlayerData> callback = null)
IEnumerator Download(int id, System.Action<PlayerData> callback = null)

{
    using (UnityWebRequest request = UnityWebRequest.Get("http://localhost:3000/plummies/" + id))
    {
        yield return request.SendWebRequest();

        if (request.isNetworkError || request.isHttpError)
        {
            Debug.Log(request.error);
            if (callback != null)
            {
                callback.Invoke(null);
            }
        }
        else
        {
            if (callback != null)
            {
                callback.Invoke(PlayerData.Parse(request.downloadHandler.text));
            }
        }
    }
}

IEnumerator Upload(string profile, System.Action<bool> callback = null)
{
    using (UnityWebRequest request = new UnityWebRequest("http://localhost:3000/plummies", "POST"))
    {
        request.SetRequestHeader("Content-Type", "application/json");
        byte[] bodyRaw = Encoding.UTF8.GetBytes(profile);
        request.uploadHandler = new UploadHandlerRaw(bodyRaw);
        request.downloadHandler = new DownloadHandlerBuffer();
        yield return request.SendWebRequest();

        if (request.isNetworkError || request.isHttpError)
        {
            Debug.Log(request.error);
            if(callback != null) 
            {
                callback.Invoke(false);
            }
        }
        else
        {
            if(callback != null) 
            {
                callback.Invoke(request.downloadHandler.text != "{}");
            }
        }
    }
}


    // Start is called before the first frame update
    private void Start()
    {
        rb = GetComponent<Rigidbody2D>(); 
        anim = GetComponent<Animator>();
        sprite = GetComponent<SpriteRenderer>();  //to make sprite turn around/flip
        moveSpeed = 9f;
        jumpHeight = 12f;
        //from playerData.cs
        _playerData = new PlayerData();
        _playerData.player_coins = itemCollector.coins;
        //_playerData.player_coins = 1;
        //Debug.Log(itemCollector.coins);
        Debug.Log(_playerData.player_coins); //prints to terminal

        StartCoroutine(Download(_playerData.player_coins, result => {
        Debug.Log(result);
        }));
    }

    // Update is called once per frame
    void Update()
    {
        movement = Input.GetAxisRaw("Horizontal");
        rb.velocity = new Vector2(movement * moveSpeed, rb.velocity.y);

        if(Input.GetButtonDown("Jump")) 
        {
            rb.velocity = new Vector2(rb.velocity.x, jumpHeight); //2nd argument is vertical height
        }
        UpdateAnimationState();

    }
    void FixedUpdate() 
    {
    // Movement logic here ...

    //if(_rigidBody2D.position.x > 24.0f && _isGameOver == false) {
        StartCoroutine(Upload(_playerData.Stringify(), result => {
            Debug.Log(result);
        }));

    //}
    }

    private void UpdateAnimationState()
    {
        if (movement > 0f) //if character is moving right
        {
            anim.SetBool("running", true);
            sprite.flipX = false; //unflip sprite
        }
        else if (movement < 0f) //if character is moving left
        {
            anim.SetBool("running", true);
            sprite.flipX = true; //flip sprite
        }
        else // if character is not moving
        {
            anim.SetBool("running", false);
        }        

    }
}
