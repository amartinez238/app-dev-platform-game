using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class itemCollector : MonoBehaviour
{  
    public static int coins = 1;
    [SerializeField] private TextMeshProUGUI coinText;
    private void OnTriggerEnter2D(Collider2D collision)
    {
        //checks tag name given near top of coin inspector tab
        if(collision.gameObject.CompareTag("coin"))
        {
            Destroy(collision.gameObject);
            coins += 1;
            //Debug.Log("coins: " + coins);
            coinText.text = "Coins:" + coins;
        }
    }
}
